package com.cg.service;

import com.cg.dao.LogInDaoImpl;
import com.cg.dto.LogIn;

public class LoginServiceImpl {
	LogInDaoImpl logInDao=null;
	public LoginServiceImpl()
	{
		logInDao = new LogInDaoImpl();
	}
	public LogIn getUserDetails(String unm)
	{
		return logInDao.getUserDetails(unm);
	}

}
