package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.LogIn;
import com.cg.service.LoginServiceImpl;


@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ServletConfig config=null;
	


	public LoginController() {
		super();
	}


	public void init(ServletConfig config) throws ServletException 
	{
		super.init(config);
		this.config=config;
	}


	public void destroy() 
	{

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request,response);
	}


	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException,
			IOException 
	{
		LoginServiceImpl logser=new LoginServiceImpl();

		String action=request.getParameter("action");
		ServletContext ctx=config.getServletContext();
		String cn=(String)ctx.getInitParameter("compname");
		ctx.setAttribute("compNameobj", cn);
		if(action!=null)
		{
			RequestDispatcher rd=null;
			if(action.equalsIgnoreCase("ShowHomePage"))
			{
				rd=request.getRequestDispatcher("Pages/Home.jsp");
				rd.forward(request, response);
			}
			
			if(action.equalsIgnoreCase("ShowLoginPage"))
			{
				rd=request.getRequestDispatcher("Pages/Login.jsp");
				rd.forward(request, response);
			}
			
			if(action.equalsIgnoreCase("ValidateData"))
			{
				String un=request.getParameter("txtUname");
				String pwd=request.getParameter("txtPwd");
				rd.forward(request, response);
		
				LogIn user=logser.getUserDetails(un);
				if(un.equalsIgnoreCase(user.getUserName())&&(pwd.equalsIgnoreCase(user.getPassword())))
			{
		HttpSession session=request.getSession(true);
		session.setAttribute("usernameObj", un);
		rd=request.getRequestDispatcher("Pages/Success.jsp");
				rd.forward(request, response);
			}
				else{
					String errMsg="Incorrect Password Please Enter Again";
					request.setAttribute("MsgObj",errMsg);
					rd=request.getRequestDispatcher("Pages/Login.jsp");
					rd.forward(request, response);
				}
			
		
			
		}
		else
		{
			PrintWriter out=response.getWriter();
			out.println("No Action Defined....");
		}
	}
	}
}
