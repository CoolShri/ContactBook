package com.cg.dao;

import com.cg.bean.Account;
import com.cg.bean.Customer;
import com.cg.util.util;

public class paymentImpl implements payment{
util u=new util();
	@Override
	public int createAccount(Customer cust,Account acc) {
	return u.createAccount(cust,acc);
		
	}
	@Override
	public int show_balance(int accno) {
		return u.show_balance(accno);
		
	
	}
	public int updateBalance(int accno,int bal){
	
		return 	u.updateBalance(accno,bal);
	}
	@Override
	public int withdraw(int accno, int bal) {
		
		return u.withdraw(accno, bal);
	}
	@Override
	public int fundTransfer(int myacc, int depacc, int bal) {
	
		return u.fundTransfer(myacc, depacc, bal);
	}

}
