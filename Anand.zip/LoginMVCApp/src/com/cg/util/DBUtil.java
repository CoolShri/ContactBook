package com.cg.util;


import java.sql.Connection;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;



public class DBUtil {
	public static Connection getCon(){
		Context ctx =null;
		Connection con = null;
		DataSource ds = null;
		try{
			ctx = new InitialContext();
			ds=(DataSource)ctx.lookup("java:/jdbc/OracleDS");
			con = ds.getConnection();
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return con;
	}
}
