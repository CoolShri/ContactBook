package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.dto.Login;
import com.cg.util.DBUtil;

public class LoginDaoImpl {
	Connection con = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	Statement st = null;

	public LoginDaoImpl() {
	}

	public Login getUserDetails(String unm) throws SQLException {
		con = DBUtil.getCon();
		System.out.println("In Dao Got Connection " + con);
		String sql = "select * from LOGIN_TBL where user_name=?";
		Login usr = null;
		pst = con.prepareStatement(sql);
		pst.setString(1, unm);
		rs = pst.executeQuery();
		rs.next();
		usr = new Login(rs.getString("user_name"), rs.getString("user_pass"));
		return usr;
	}
	public ArrayList<Login> getAllUsers() throws Exception{
		ArrayList<Login> userList = new ArrayList<Login>();
		con=DBUtil.getCon();
		st=con.createStatement();
		rs = st.executeQuery("select * from login_tbl");
		while(rs.next()){
			
			userList.add(new Login(rs.getString("user_name"),rs.getString("user_pass")));
		}
		
		
		return userList;
	}
}
