package com.cg.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.dao.LoginDaoImpl;
import com.cg.dto.Login;

public class LoginServiceImpl {
	LoginDaoImpl loginDao = null;

	public LoginServiceImpl() {
		loginDao = new LoginDaoImpl();
	}

	public Login getUserDetails(String unm) throws SQLException {
		return loginDao.getUserDetails(unm);
	}

	public ArrayList<Login> getAllUsers() throws Exception {
		return loginDao.getAllUsers();
	}
}
