package com.spring.mvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ControllerPage 
{

	@RequestMapping("/")
	public String blankPage()
	{
		String view="HomePage";
		return view;
	}
	@RequestMapping(value="/log", method=RequestMethod.GET)
	public String loginpage(Model model)
	{
		String view="LoginPage";
		model.addAttribute("msg","Welcome To Login Page");
		return view;
	}
	@RequestMapping(value="/log", method=RequestMethod.POST)
	public String validatelogin(@RequestParam("username") String user,@RequestParam("pwd") String pass,Model model)
	{
		String view=null;
		if("admin".equalsIgnoreCase("user") && "admin".equalsIgnoreCase("pass"))
		{
			view="Success";
			model.addAttribute("msg","Successfully Login"+user);
		}
		else
		{
		view="failure";
		model.addAttribute("msg","Login Failed");
		}
		return view;
	}
	
	
}
