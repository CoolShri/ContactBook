package com.cg.productmgmt.service;

import java.util.Map;

public interface IProductService {
//interfaces
	
	public int updateProducts(String Category,int hike,String key);
	public Map<String,String>getProductDetails();
}
