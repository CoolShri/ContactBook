package com.cg.productmgmt.dao;

import java.util.Map;

public interface IProductDao {

	//interfaces
	public int updateProducts(String Category,int hike,String key);
	public Map<String,String>getProductDetails();
}
