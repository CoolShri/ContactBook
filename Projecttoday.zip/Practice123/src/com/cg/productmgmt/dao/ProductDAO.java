package com.cg.productmgmt.dao;

import java.util.Map;

import com.cg.productmgmt.util.util;

public class ProductDAO implements IProductDao{

	@Override
	public int updateProducts(String Category, int hike,String key) {
		util u=new util();
		
		return u.updateProducts(Category, hike,key);
	
	
	}

	@Override
	public Map<String, String> getProductDetails() {
	
		util u=new util();
		return util.productDetails;
	}
	
	public Map<String,Integer>getdetails()
	{
		util u=new util();
		return util.SalesDetails;
	}

}
