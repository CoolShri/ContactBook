package com.cg.productmgmt.util;

import java.util.HashMap;
import java.util.Map;

public class util {

	
	public static Map<String,String>productDetails;
	public	static Map<String,Integer>SalesDetails;
	
	
	static 
	{
		
		productDetails=new HashMap<>();
		productDetails.put("lux","soap");
		productDetails.put("colgate","paste");
		productDetails.put("pears","soap");
		productDetails.put("sony","electronics");
		productDetails.put("samsung","electronics");
		productDetails.put("facepack","cosmatic");
		productDetails.put("facecream","cosmatic");
		
	
	
	
		SalesDetails=new HashMap<>();
		SalesDetails.put("lux",100);
		SalesDetails.put("colgate",50);
		SalesDetails.put("pears",70);
		SalesDetails.put("sony",10000);
		SalesDetails.put("samsung",23000);
		SalesDetails.put("facepack",100);
		SalesDetails.put("facecream",60);
		
	}
	public int updateProducts(String Category,int hike,String key)
	{
		
		SalesDetails.replace(productDetails.get(key), hike);
		return hike;
		
	}
}
